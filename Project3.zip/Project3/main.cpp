#include <cstdint>
#include <iostream>
#include <unistd.h>

using namespace std;

// arrow keys: 27 91 x
// x == 65: up
// x == 66: down
// x == 67: right
// x == 68: left

const string
    UL_ROUND = "\u256d",
    UR_ROUND = "\u256e",
    LR_ROUND = "\u256f",
    LL_ROUND = "\u2570",
    UL_DOUBLE = "\u2554",
    UR_DOUBLE = "\u2557",
    LL_DOUBLE = "\u255a",
    LR_DOUBLE = "\u255d",
    H_SINGLE = "\u2500",
    V_SINGLE = "\u2502",
    H_DOUBLE = "\u2550",
    V_DOUBLE = "\u2551",
    CROSS_DOUBLE = "\u256c",
    L_DOUBLE_TEE = "\u2560",
    R_DOUBLE_TEE = "\u2563",
    U_DOUBLE_TEE = "\u2566",
    D_DOUBLE_TEE = "\u2569";

//=============================================================================
// void drawBoardFrame()
//  draw an empty board
//

void drawBoardFrame() {

    // clear the screen
    cout << "\033[2J\033[H";

    // draw the score area
    // set color to green
    cout << "\033[32m";
    // top border
    cout << UL_ROUND;
    for (uint32_t i=0;i<27;i++)
        cout << H_SINGLE;
    cout << UR_ROUND << endl;

    // middle line with the score
    cout << V_SINGLE << " Score: 0                  " << V_SINGLE << endl;

    // bottom border
    cout << LL_ROUND;
    for (uint32_t i=0;i<27;i++)
        cout << H_SINGLE;
    cout << LR_ROUND << endl;

    // draw the 4x4 grid
    // set the color to blue
    cout << "\033[34m";
    // top border of top row
    cout << UL_DOUBLE;
    // three groups of 6 horizontal segments then a tee... first three columns
    for (uint32_t i=0;i<3;i++) {
        for (uint32_t j=0;j<6;j++)
            cout << H_DOUBLE;
        cout << U_DOUBLE_TEE;
    }
    // fourth column, 6 horizontal segments then the top-right corner
    for (uint32_t j=0;j<6;j++)
        cout << H_DOUBLE;
    cout << UR_DOUBLE << endl;

    // draw three rows
    for (uint32_t i=0;i<3;i++) {
        // four columns... vertical line then 6 spaces
        for (uint32_t j=0;j<4;j++)
            cout << V_DOUBLE << "      ";
        // vertical line segment at the right edge
        cout << V_DOUBLE << endl;
        // draw the separator between rows, start with left tee
        cout << L_DOUBLE_TEE;
        // then first three columns... 6 horizontal segments then a cross
        for (uint32_t j=0;j<3;j++) {
            for (uint32_t k=0;k<6;k++)
                cout << H_DOUBLE;
            cout << CROSS_DOUBLE;
        }
        // fourth column... 6 horizontal segments then a right tee
        for (uint32_t k=0;k<6;k++)
            cout << H_DOUBLE;
        cout << R_DOUBLE_TEE << endl;
    }

    // then the bottom row
    // four columns, vertical segment then 6 spaces
    for (uint32_t j=0;j<4;j++)
        cout << V_DOUBLE << "      ";
    // vertical segment at the right edge
    cout << V_DOUBLE << endl;
    // bottom border, like the top border except for corners and tees
    cout << LL_DOUBLE;
    for (uint32_t j=0;j<3;j++) {
        for (uint32_t k=0;k<6;k++)
            cout << H_DOUBLE;
        cout << D_DOUBLE_TEE;
    }
    for (uint32_t k=0;k<6;k++)
        cout << H_DOUBLE;
    cout << LR_DOUBLE << endl;

    // set color back to white on black
    cout << "\033[0m";
}



//=============================================================================
// void fillCell(uint32_t board[][4])
//  select an empty cell at random, fill with random 2 or 4
//
// Parameter
//  board - the 4x4 game board
//
// Notes:
// - 2 is selected randomly based on parameter p2 = N2 / D2
// - 4 is selected randomly with probability 1 - p2
//

void fillCell(uint32_t board[][4]) {

}



//=============================================================================
// int main()
//  the main function
//
// Returns
//  0
//

int main() {
    uint32_t
        board[4][4]={0},        // the board
        score = 0;              // current score
    bool
        gameOver = false;       // set flag when game is over

    // draw the empty board frame... drawBoard() fills in the details
    drawBoardFrame();

    // prepare console input, no enter required, no echo of characters
    system("stty raw -echo");

    // initialize the game

    // play the game
    while (!gameOver) {
        int32_t
            ch = getchar();
        cout << ch << '\r' << endl;

        switch (ch) {
            case 'q':
            case 'Q':
                gameOver = true;
                break;
            default:
                ;  // do nothing
                // optional: display an error message for invalid input
                // cout << "\033[14;1HInvalid input" << endl;
                // sleep(2);
                // cout << "\033[14;1H\033[J";  // erase error msg
        }
    }

    // restore console input
    system("stty cooked echo");

    return 0;
}